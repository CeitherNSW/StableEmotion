# StableEmotion > 2023-07-28 3:08pm
https://universe.roboflow.com/stableemotion/stableemotion

Provided by a Roboflow user
License: CC BY 4.0

